package br.com.fenix.dominio.uuid;

import java.util.EnumSet;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.generator.BeforeExecutionGenerator;
import org.hibernate.generator.EventType;
import org.hibernate.generator.EventTypeSets;

//import com.fasterxml.uuid.Generators;

public class UlidGenerator implements BeforeExecutionGenerator {

	@Override
	public EnumSet<EventType> getEventTypes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object generate(SharedSessionContractImplementor session, Object owner, Object currentValue,
			EventType eventType) {
		// TODO Auto-generated method stub
		return null;
	}

//    @Override
//    public EnumSet<EventType> getEventTypes() {
//        return EventTypeSets.INSERT_ONLY;
//    }
//
//	@Override
//	public Object generate(SharedSessionContractImplementor session, Object owner, Object currentValue,
//			EventType eventType) {
//		  return Generators.timeBasedEpochGenerator().generate();
//	}
}