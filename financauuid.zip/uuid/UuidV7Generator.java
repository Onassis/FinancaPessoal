package br.com.fenix.dominio.uuid;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.enhanced.SequenceStyleGenerator;

//import com.fasterxml.uuid.Generators;

public class UuidV7Generator extends SequenceStyleGenerator {
    @Override
    public Object generate(SharedSessionContractImplementor session, Object object) {
//        return Generators.timeBasedEpochGenerator().generate();
        return null;
    }
}